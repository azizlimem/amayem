#include<gtk/gtk.h>
#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED

typedef struct Date
{
int jour;
int mois;
int annee;
}Date;
typedef struct user {
char nom[30];
char prenom[30];
char mdp[30];
char sexe[30];
char id[30];
char poste[100];
Date date;
}user;

void ajouter_user(user u);
void supprimer_user(user u);
void modifier_user(user u);
void afficher_user(GtkWidget *liste);
void chercher_user(user u);
/*void afficher_u_chercher(GtkWidget *liste);*/
/*int verifier (user u);*/
int exist_id(char* id);
int verifier_ID_inscrit(char id[30]);
void afficher_A_rechercher(GtkWidget *liste);
int verifier_PASSWORD_inscrit(char password[30]);
int radio;

#endif // FONCTION_H_INCLUDED
