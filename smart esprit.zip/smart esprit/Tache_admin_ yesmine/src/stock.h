#include<gtk/gtk.h>


typedef struct date {
int jour;
char mois[40];
char annee[40];
}date;

typedef struct stock {
char nom[40];
int identifiant;
char type[40];
char quantite[40];
int quantite_restante;
date d;
}stock;
//déclaration des fonctions 

void ajouter_s(stock s);
void chercher_s (stock s);
void supprimer_s(stock s);
void modifier_s(stock s);
void affichage (GtkWidget *liste);
void afficher_s_chercher(GtkWidget *liste);
int verifier (stock s);
void alert_stock(stock s);
void afficher_alert_stock(GtkWidget *liste);

int s;
int x;
int l;
int r;
