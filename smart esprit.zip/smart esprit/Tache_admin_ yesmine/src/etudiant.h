#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>

typedef struct date1
{
    char jour[20];
    char mois[20];
    char annee[20];

}date1;
typedef struct etudiant
{ char nom[30];
  char prenom[30];
  char cin[30];
  char id[30];
  char sexe[30];
  char niv[30];
  date1 dte;}etudiant;
void afficher_etud(GtkWidget* treeview);
void ajouter_etud(etudiant e);
void supprimer_etud(etudiant e);
void rechercher_etud(etudiant e);
void modifier_etud(etudiant e);
int verifd(char id[]);
int veriff(char x[]);
void afficher_niveaux(char niveau[],GtkWidget* treeview);
void afficher_etud_rech(GtkWidget* liste);
