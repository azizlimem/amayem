


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "fonctionsadmin.h"
#include<gtk/gtk.h>

enum
{
	NOM,
	PRENOM,
	ID,
	SEXE,
	POSTE,
	JOUR,
	MOIS,
	ANNEE,
	MDP,
	COLUMNS
};
//////////////////////////////////////////

void ajouter_user(user u)
{
	char nom[30];
	char prenom[30];
	char id[30];
	char sexe[30];
	char poste[30];
	char mdp[30];
	int jour;
	int mois;
	int annee;

FILE *f;
f=fopen("utilisateur.txt","a+");

if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s  %d %d %d %s \n",u.nom,u.prenom,u.id,u.sexe,u.poste,u.date.jour,u.date.mois,u.date.annee,u.mdp);
fclose(f);

}



}

//////////////////////////////////////////


///////////////////////////////////////////////////

void afficher_user(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;


	GtkListStore *store;


	char nom[100];
	char prenom[100];
	char id[100];
	char sexe[100];
	char poste[100];
	char mdp[100];
	int jour;
	int mois;
	int annee;
	
	store=NULL;

FILE *f;

store = gtk_tree_view_get_model(liste);

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" poste",renderer,"text",POSTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" mdp",renderer,"text",MDP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);
f=fopen("utilisateur.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("utilisateur.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %d %d %d %s\n",nom,prenom,id,sexe,poste,&jour,&mois,&annee,mdp)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter, NOM, nom, PRENOM, prenom,ID, id, SEXE, sexe, POSTE, poste, JOUR, jour, MOIS, mois, ANNEE, annee, MDP, mdp, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//////////////////////////////////////////////////
void modifier_user(user u)


{

FILE *f;
FILE *t;
	 char nom[30];
	char prenom[30];
	char id[30];
	char poste[30];
	char sexe[30];
	char mdp[30];
	int jour;
	int mois;
	int annee;
	//char num[30];

f=fopen("utilisateur.txt","r");
t=fopen("utilis.txt","a");

    if (f!=NULL || t!=NULL)
    {
    while(fscanf(f,"%s %s %s %s %s %d %d %d %s \n",nom,prenom,id,sexe,poste,&jour,&mois,&annee,mdp)!=EOF)
    {

        if(strcmp(u.id,id)==0)
        {
            fprintf(t,"%s %s %s %s %s %d %d %d %s\n",u.nom,u.prenom,u.id,u.sexe,u.poste,u.date.jour,u.date.mois,u.date.annee,u.mdp);
        }
        else
            fprintf(t,"%s %s %s %s %s %d %d %d %s\n",nom,prenom,id,sexe,poste,jour,mois,annee,mdp);
        }
    }

fclose(t);
fclose(f);
remove("utilisateur.txt");
rename("utilis.txt","utilisateur.txt");
}









//////////////////////////////////////
void supprimer_user(user u)
{

	char nom[30];
	char prenom[30];
	char id[30];
	char sexe[30];
	char poste[30];
	char mdp[30];
	int jour;
	int mois;
	int annee;
	
FILE *f,*g;

f=fopen("utilisateur.txt","r");
g=fopen("dump.txt","w");


if (f==NULL || g==NULL)
{
return;
}
else
{ 


	while(fscanf(f,"%s %s %s %s %s %d %d %d %s",nom,prenom,id,sexe,poste,&jour,&mois,&annee,mdp)!=EOF)
	{
	if(strcmp(u.nom,nom)!=0 || strcmp(u.prenom,prenom)!=0 || strcmp(u.id,id)!=0 ||strcmp(u.sexe,sexe)!=0 || strcmp(u.poste,poste)!=0 || u.date.jour!=jour ||u.date.mois!=mois || u.date.annee!=annee || strcmp(u.mdp,mdp)!=0)

	fprintf(g,"%s %s %s %s %s %d %d %d %s\n",nom,prenom,id,sexe,poste,jour,mois,annee,mdp);	
	
	}
}
fclose(f);
fclose(g);

remove("utilisateur.txt");
rename("dump.txt","utilisateur.txt");

}




///////////////////////////////
void chercher_user( user u)
{
FILE* f; 
FILE* f1;
	char nom[30];
	char prenom[30];
	char id[30];
	char sexe[30];
	char poste[30];
	char mdp[30];
	int jour;
	int mois;
	int annee;
	

	//char num[30];

f=fopen("utilisateur.txt","r");
f1=fopen("utilcher.txt","w");
 	while(fscanf(f,"%s %s %s %s %s %d %d %d %s\n",nom,prenom,id,sexe,poste,&jour,&mois,&annee,mdp)!=EOF)
	{
		if (strcmp(u.id,id)==0)
		{
		fprintf(f1,"%s %s %s %s %s %d %d %d %s\n",nom,prenom,id,sexe,poste,jour,mois,annee,mdp);
		}
	}
	fclose(f);
	fclose(f1);
//remove("utilisateurchercher.txt");
//rename ("utilcher.txt","utilisateurchercher.txt");
}
//-------------------Affichage de rechercher---------------
void afficher_A_rechercher(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	char nom[30];
	char prenom[30];
	char id[30];
	char sexe[30];
	char poste[30];
	char mdp[30];
	int jour;
	int mois;
	int annee;
	store=NULL;

FILE *f;

store = gtk_tree_view_get_model(liste);

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" poste",renderer,"text",POSTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" mdp",renderer,"text",MDP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);
f=fopen("utilcher.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("utilcher.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %d %d %d %s\n",nom,prenom,id,sexe,poste,&jour,&mois,&annee,mdp)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter, NOM, nom, PRENOM, prenom,ID, id, SEXE, sexe, POSTE, poste, JOUR, jour, MOIS, mois, ANNEE, annee, MDP, mdp, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

}








/*void chercher_user(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	
	char nom[100];
	char prenom[100];
	char id[100];
	char poste[100];
	
	store=NULL;

	FILE *f;
	if(store==NULL)
	{


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("poste",renderer,"text",EPOSTE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("recherche.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f=fopen("recherche.txt","a+");
		while(fscanf(f,"%s %s %s %s \n",nom,prenom,id,poste)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set (store,&iter,ENOM,nom,EPRENOM,prenom,EID,id,EPOSTE,poste,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
		g_object_unref (store);

	}
	remove("recherche.txt");
        
	
}


/*=================================fonction verifier ID=================================*/
int exist_id(char* id){
FILE*f=NULL;
user u;
f=fopen("utilisateur.txt","r");// ouverture du fichier plante en  mode lecture 
while(fscanf(f,"%s %s %s %s %s %d %d %d %s \n",u.nom,u.prenom,u.id,u.sexe,u.poste,&u.date.jour,&u.date.mois,&u.date.annee,u.mdp)!=EOF){
if(strcmp(u.id,id)==0)
return 1;   //id existe deja 
}
fclose(f);
return 0;
}
//fonction verifier ID
int verifier_ID_inscrit(char id[30])
{ 
FILE*f=NULL;
user u;
f=fopen("utilisateur.txt","r");
while(fscanf(f,"%s %s %s %s %s %d %d %d %s \n",u.nom,u.prenom,u.id,u.sexe,u.poste,&u.date.jour,&u.date.mois,&u.date.annee,u.mdp)!=EOF){
if((strcmp(u.id,id)==0)||(strcmp(id,"admin")==0))
return 1; //existe   
}
fclose(f);
return 0; //n'existe pas
}

//fonction verifier PASSEWORD
int verifier_PASSWORD_inscrit(char password[30])
{ 
if(strcmp("admin",password)==0)
	{
	return 0; //Administrateur  
	}else
if(strcmp("stock",password)==0)
	{
	return 1; //Agent de stock 
	}else
if(strcmp("foyer",password)==0)
	{
	return 2; //Agent de Foyer  
	}else

if(strcmp("technicien",password)==0)
	{
	return 3; //technicien  
	}else
if(strcmp("restaurant",password)==0)
	{
	return 4; //Agent de restaurant  
	}else
if(strcmp("etudiant",password)==0)
	{
	return 5; //reclamation  
	}else
  
	
{ return 7; }

}
int verifier_ACCEE_inscrit(char id[30])
{
FILE*f=NULL;
user u;
f=fopen("utilisateur.txt","r");
 while(fscanf(f,"%s %s %s %s %s %d %d %d %s \n",u.nom,u.prenom,u.id,u.sexe,u.poste,&u.date.jour,&u.date.mois,&u.date.annee,u.mdp)!=EOF)
	{
	if (strcmp(u.id,id)==0)
		{
		if (strcmp(u.poste,"Admin")==0)
		return 1;
		if (strcmp(u.poste,"Agent_de_Stock")==0)
		return 2;
		if (strcmp(u.poste,"Agent_de_Foyer")==0)
		return 3;
		if (strcmp(u.poste,"Technicien")==0)
		return 4;
		if
	(strcmp(u.poste,"Agent_de_Restaurant")==0)
		return 5;
		if (strcmp(u.poste,"Etudiant")==0)
		return 6;
		
		}
	}}

