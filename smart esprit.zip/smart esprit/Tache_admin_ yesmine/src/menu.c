
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "menu.h"
enum{
	HID,
	HFN,
	HLN,
	HG,
	HRN,
	HRF,
	HRT,
        HCL,
	COLUMNS
};
void add_menu(menu e,char *file){
	FILE *f;
	f=fopen(file,"a+");
	if(f!=NULL)
	{
		fprintf(f,"%s %s %s %d %d %s %s %s\n",e.id,e.meal,e.dessert,e.day,e.dechets,e.size,e.type,e.cal);
	}
	fclose(f); 
}

void modify_menu(menu e,char *file)
{
menu e1;

FILE* f=fopen(file,"r+");
FILE* g=fopen("tmp.txt","w");
if(f!=NULL)
{
	while(fscanf(f,"%s %s %s %d %d %s %s %s\n",e1.id,e1.meal,e1.dessert,&e1.day,&e1.dechets,e1.size,e1.type,e1.cal)!=EOF)
	{
		
		if(strcmp(e.id,e1.id)==0)
		{
			fprintf(g,"%s %s %s %d %d %s %s %s\n",e.id,e.meal,e.dessert,e.day,e.dechets,e.size,e.type,e.cal);
		}
		else
		{
			fprintf(g,"%s %s %s %d %d %s %s %s\n",e1.id,e1.meal,e1.dessert,e1.day,e1.dechets,e1.size,e1.type,e1.cal);
		}

	}
}
fclose(f);
fclose(g);
remove(file);
rename("tmp.txt",file);
}
void delete_menu(char id_menu[20],char *file){
	menu e;
	FILE *f,*ftmp;
	f=fopen(file,"r");
	ftmp=fopen("tmp.txt","a+");
	while(fscanf(f,"%s %s %s %d %d %s %s %s\n",e.id,e.meal,e.dessert,&e.day,&e.dechets,e.size,e.type,e.cal)!=EOF)
		{
			if(strcmp(e.id,id_menu)!=0){
				fprintf(ftmp,"%s %s %s %d %d %s %s %s\n",e.id,e.meal,e.dessert,e.day,e.dechets,e.size,e.type,e.cal);
			}
		}
	fclose(ftmp);
	fclose(f);
	remove(file);
	rename("tmp.txt",file);	
}

void search_menu(char id_menu[20],char *file){
	menu e;
	FILE *f,*g;
	f=fopen(file,"r");
	g=fopen("search.txt","a+");
	while(fscanf(f,"%s %s %s %d %d %s %s %s\n",e.id,e.meal,e.dessert,&e.day,&e.dechets,e.size,e.type,e.cal)!=EOF){
		if(strcmp(e.id,id_menu)==0){
			fprintf(g,"%s %s %s %d %d %s %s %s\n",e.id,e.meal,e.dessert,e.day,e.dechets,e.size,e.type,e.cal);
		}
	}
	fclose(f);
	fclose(g);
}

void display_menu_ONtreeview(GtkWidget *list,char *file){
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter ;
	GtkListStore *store;
	menu h;
	
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(list);
	if(store==NULL){
	
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("ID",renderer,"text",HID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("Meal",renderer,"text",HFN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

		 renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("Dessert",renderer,"text",HLN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column); 

		 renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("Size",renderer,"text",HG,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
 
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("Day",renderer,"text",HRN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("dechets",renderer,"text",HRF,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("Type",renderer,"text",HRT,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);
                 

                renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("Calorie",renderer,"text",HCL,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(list),column);

		
		 
	}
		  
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen(file,"r");
	if(f==NULL){return;}
	else
	{
		 while(fscanf(f,"%s %s %s %d %d %s %s %s\n",h.id,h.meal,h.dessert,&h.day,&h.dechets,h.size,h.type,h.cal)!=EOF)
		 {
			
			gtk_list_store_append(store,&iter);
			
		  	gtk_list_store_set(store,&iter,HID,h.id,HFN,h.meal,HLN,h.dessert,HG,h.size,HRN,h.day,HRF,h.dechets,HRT,h.type,HCL,h.cal,-1);
		 }
	 fclose(f);
	 gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));
	 g_object_unref(store);
	}

}




void meilleur_menu(  char *file)
{ 
menu e;
int dechets1=100,day1;
char dessert1[20],type1[20],meal1[20],cal1[20],size1[20],id1[20];
	FILE *f,*g;
	f=fopen(file,"r");
	g=fopen("best.txt","a+");
	while(fscanf(f,"%s %s %s %d %d %s %s %s\n",e.id,e.meal,e.dessert,&e.day,&e.dechets,e.size,e.type,e.cal)!=EOF){
		if(e.dechets<dechets1){
			dechets1=e.dechets;
			strcpy(id1,e.id);
			day1=e.day;
			strcpy(dessert1,e.dessert);
			strcpy(size1,e.size);
			strcpy(type1,e.type);
			strcpy(cal1,e.cal);
			strcpy(meal1,e.meal);
		}
	}
fprintf(g,"%s %s %s %d %d %s %s %s\n",id1,meal1,dessert1,day1,dechets1,size1,type1,cal1);
	fclose(f);
	fclose(g);
}
	   
 	







