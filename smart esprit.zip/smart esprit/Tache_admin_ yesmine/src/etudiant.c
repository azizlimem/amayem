#include"etudiant.h"
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<time.h>

enum{ENOM,EPRENOM,ECIN,EID,ESEXE,ENIVEAU,EDATE,COLUMNS};
enum{ENOMM,EPRENOMM,ECINN,EIDD,ESEXEE,ENIVEAUU,EDATEE,COLUMNSS};




void ajouter_etud(etudiant e)
{FILE *f;
f=fopen("etuds.txt","a+");
if(f!=NULL)
{fprintf(f,"%s %s %s %s %s %s %s %s %s \n",e.nom,e.prenom,e.cin,e.id,e.sexe,e.niv,e.dte.jour,e.dte.mois,e.dte.annee);}
fclose(f);
}

 int verifd(char id[])
{
   etudiant e;
   int res = 1;
   FILE *f;
   f = fopen("etuds.txt", "a+");
   if (f != NULL)
   {
      while (fscanf(f,"%s %s %s %s %s %s %s %s %s \n",e.nom,e.prenom,e.cin,e.id,e.niv,e.sexe,e.dte.jour,e.dte.mois,e.dte.annee)!=EOF)
      {
         if (strcmp(id,e.id) == 0)
         {
            res = 0;
         }
         else
         {
            res = 1;
         }
      }
   }
   fclose(f);
   return res;
}
int veriff(char x[])
{
   int i;
   if (strcmp(x,"")==0)
   {
      i=0;
   }
   else
   {
      i=1;
   }
return i;}

void afficher_etud(GtkWidget* liste)
{	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
etudiant e;
char Nom[30];
char Prenom[30];
char Cin[30];
char Id[30];
char Niveau[30];
char Date[100];
char Sexe[30];
char jj[20],mm[20],aa[20];

store=NULL;
FILE* f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Cin",renderer,"text",ECIN,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Id",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Niveau",renderer,"text",ENIVEAU,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("etuds.txt","r");
if(f==NULL)
{return;}
else
{f=fopen("etuds.txt","a+");
while(fscanf(f," %s %s %s %s %s %s %s %s %s \n",Nom,Prenom,Cin,Id,Sexe,Niveau,jj,mm,aa)!=EOF)
{

gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,ENOM,Nom,EPRENOM,Prenom,ECIN,Cin,EID,Id,ESEXE,Sexe,ENIVEAU,Niveau,EDATE,strcat(strcat(strcat(strcat(jj,"/"),mm),"/"),aa),-1);
}
  fclose(f);
  gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
  g_object_unref(store);}}


void rechercher_etud(etudiant e)
{FILE* f;
FILE* f1;
char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char niveau[20];
char jj[20];
char mm[20];
char aa[20];
f=fopen("etuds.txt","r");
f1=fopen("recherche.txt","w");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,niveau,jj,mm,aa)!=EOF)
{
if (strcmp(e.id,id)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,niveau,jj,mm,aa);
}
}
fclose(f);
fclose(f1);}
void afficher_etud_rech(GtkWidget* liste)
{	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
etudiant e;
char Nom[30];
char Prenom[30];
char Cin[30];
char Id[30];
char Niveau[30];
char Date[100];
char Sexe[30];
char jj[20],mm[20],aa[20];

store=NULL;
FILE* f1;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Cin",renderer,"text",ECIN,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Id",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Niveau",renderer,"text",ENIVEAU,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f1=fopen("recherche.txt","r");
if(f1==NULL)
{return;}
else
{f1=fopen("recherche.txt","a+");
while(fscanf(f1," %s %s %s %s %s %s %s %s %s \n",Nom,Prenom,Cin,Id,Sexe,Niveau,jj,mm,aa)!=EOF)
{

gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,ENOM,Nom,EPRENOM,Prenom,ECIN,Cin,EID,Id,ESEXE,Sexe,ENIVEAU,Niveau,EDATE,strcat(strcat(strcat(strcat(jj,"/"),mm),"/"),aa),-1);
}
  fclose(f1);
  gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
  g_object_unref(store);}}
void supprimer_etud(etudiant e)
{
char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char niveau[20];
char jj[20];
char mm[20];
char aa[20];
FILE* f;
FILE *f2;
f=fopen("etuds.txt","r");
f2=fopen("supp.txt","a+");
if(f2!=NULL){
  if(f!=NULL)
{while(fscanf(f," %s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,niveau,jj,mm,aa)!=EOF)
{
   if(strcmp(e.id,id)!=0)
fprintf(f2,"%s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,niveau,jj,mm,aa);
}}fclose(f);
fclose(f2);
remove("etuds.txt");
rename("supp.txt","etuds.txt");
}}

void modifier_etud(etudiant e)
{  supprimer_etud(e);
   ajouter_etud(e);

}
void afficher_niveaux(char niv[30],GtkWidget* liste)
 {       GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
etudiant e;
char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char niveau[20];
char jj[20];
char mm[20];
char aa[20];
store=NULL;
FILE* f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",ENOMM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",EPRENOMM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Cin",renderer,"text",ECINN,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Id",renderer,"text",EIDD,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Sexe",renderer,"text",ESEXEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Niveau",renderer,"text",ENIVEAUU,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Date",renderer,"text",EDATEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}
store=gtk_list_store_new(COLUMNSS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("etuds.txt","r");
if(f==NULL)
{return;}
else
{
while(fscanf(f," %s*** %s*** %s*** %s*** %s*** %s*** %s*** %s*** %s*** \n",&nom,&prenom,&cin,&id,&sexe,&niveau,&jj,&mm,&aa)!=EOF)
{ if (strcmp(niv,niveau)==0)

{gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,ENOMM,nom,EPRENOMM,prenom,ECINN,cin,EIDD,id,ESEXEE,sexe,ENIVEAUU,niv,EDATEE,strcat(strcat(strcat(strcat(jj,"/"),mm),"/"),aa),-1);
}
  fclose(f);
  gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
  g_object_unref(store);}}}


