#ifdef HAVE_CONFIG.H
#include<config.h>
#endif


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "stock.h"
#include<gtk/gtk.h>


enum
{
	IDENTIFIANT,
	TYPE,
	NOM,
	QUANTITE,
	JOUR,
	MOIS,
	ANNEE,
	QUANTITE_RESTANTE,
	COLUMNS,
};



//**********************************Fonction Ajouter**********************************
void ajouter_s(stock s)
{
	
	char nom[30];	
	int identifiant;
	char quantite[30];
	char type[30];
	int jour;
	char mois[30];
	char annee[30];
	int quantite_restante;
FILE *f;
f=fopen("stock.txt","a+");
	if(f!=NULL)
	{
	 fprintf(f,"%d %s %s %s %d %s %s %d\n",s.identifiant,s.type,s.nom,s.quantite,s.d.jour,s.d.mois,s.d.annee,s.quantite_restante);
	 fclose(f);
	}
}

//**********************************Fonction Afficher**********************************
void affichage(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;


	GtkListStore *store;
	char nom[30];
	char type[30];	
	int identifiant;
	char quantite[30];
	int jour;
	char mois[30];
	char annee[30];
	int quantite_restante;
	store=NULL;

FILE *f;

store = gtk_tree_view_get_model(liste);

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",IDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",QUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("quantite restante",renderer,"text",QUANTITE_RESTANTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);
f=fopen("stock.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("stock.txt","a+");
		while(fscanf(f,"%d %s %s %s %d %s %s %d\n",&identifiant,type,nom,quantite,&jour,mois,annee,&quantite_restante)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter,IDENTIFIANT, identifiant,TYPE,type,NOM, nom,QUANTITE, quantite, JOUR, jour, MOIS, mois, ANNEE, annee, QUANTITE_RESTANTE, quantite_restante, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

}
/////////////////////////////////////////////////////////// fonction alerte //////////////////////////
////////////////////////////////////

void alert_stock(stock s)
{
FILE* f;
FILE* f2;
	char nom[30];
	char type[30];
	int identifiant;
	char quantite[30];
	int jour;
	char mois[30];
	char annee[30];
	int quantite_restante;
	
f=fopen("stock.txt","r");
f2=fopen("alerte.txt","w");
	while(fscanf(f,"%d %s %s %s %d %s %s %d\n",&identifiant,type,nom,quantite,&jour,mois,annee,&quantite_restante)!=EOF)
	{  if (quantite_restante ==0)
		{
		fprintf(f2,"%d %s %s %s %d %s %s %d\n",identifiant,type,nom,quantite,jour,mois,annee,quantite_restante);
		}
	}
	fclose(f);
	fclose(f2);
}
/*=================================fonction afficher alerte stock =================================*/
void afficher_alert_stock(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char nom[30];
	int identifiant;
	char type[30];
	char quantite[30];
	int jour;
	char mois[30];
	char annee[30];
	int quantite_restante;
	store=NULL;

FILE *f;
store = gtk_tree_view_get_model(liste);

if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",IDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",QUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("quantite restante",renderer,"text",QUANTITE_RESTANTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);
f=fopen("alerte.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("alerte.txt","a+");
		while(fscanf(f,"%d %s %s %s %d %s %s %d\n",&identifiant,type,nom,quantite,&jour,mois,annee,&quantite_restante)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter,IDENTIFIANT, identifiant,TYPE,type,NOM, nom,QUANTITE, quantite, JOUR, jour, MOIS, mois, ANNEE, annee, QUANTITE_RESTANTE, quantite_restante, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

}










//**********************************Fonction Supprimer**********************************

void supprimer_s(stock s)

{

	char nom[30];
	char type[30];
	int identifiant;
	char quantite[30];
	int jour;
	char mois[30];
	char annee[30];
	int quantite_restante;

FILE *f,*g;
f=fopen("stock.txt","r");
g=fopen("temp.txt","w");
if (f==NULL || g==NULL)
{
return;
}
else
{ 
	while(fscanf(f,"%d %s %s %s %d %s %s %d\n",&identifiant,type,nom,quantite,&jour,mois,annee,&quantite_restante)!=EOF)
	{
	if(s.identifiant!=identifiant|| strcmp(s.type,type)!=0 ||strcmp(s.nom,nom)!=0 || strcmp(s.quantite,quantite)!=0 ||
	 s.d.jour!=jour || strcmp(s.d.mois,mois)!=0 || strcmp(s.d.annee,annee)!=0|| s.quantite_restante!=quantite_restante )
	fprintf(g,"%d %s %s %s %d %s %s %d\n",identifiant,type,nom,quantite,jour,mois,annee,quantite_restante);

	}
fclose(f);
fclose(g);
remove("stock.txt");
rename("temp.txt","stock.txt");
}
}

/*=================================fonction Modifier=================================*/

void modifier_s(stock s)
{
FILE *f;
FILE *t;

	int identifiant;
	char type[30];
	char nom[30];
	char quantite[30];
	int quantite_restante;
	int jour;
	char mois[30];
	char annee[30];
f=fopen("stock.txt","r");
t=fopen("temp.txt","a");

    if (f!=NULL || t!=NULL)
    {
    while(fscanf(f,"%d %s %s %s %d %s %s %d\n",&identifiant,type,nom,quantite,&s.d.jour,s.d.mois,s.d.annee,&quantite_restante)!=EOF)
	{
		
		if(s.identifiant==identifiant)
		{
			fprintf(t,"%d %s %s %s %d %s %s %d\n",s.identifiant,type,s.nom,s.quantite,s.d.jour,s.d.mois,s.d.annee,s.quantite_restante);
		}
		else
			fprintf(t,"%d %s %s %s %d %s %s %d\n",identifiant,type,nom,quantite,s.d.jour,s.d.mois,s.d.annee,quantite_restante);
    	}
    }
	
fclose(t);
fclose(f);
remove("stock.txt");
rename("temp.txt","stock.txt");
}



/*=================================fonction verifier ID=================================*/
int verifier(stock s)
{
FILE *f;
	char nom[30];
	char type[30];
	int identifiant1;
	char quantite[30];
	int jour;
	char mois[30];
	char annee[30];
	int quantite_restante;
	int t,test=0;


f=fopen("stock.txt","r");

    if (f!=NULL)
    {
    while(fscanf(f,"%d %s %s %s %d %s %s %d\n",&identifiant1,type,nom,quantite,&jour,mois,annee,&quantite_restante)!=EOF)
	{
		if(s.identifiant==identifiant1)
		{
		test++;
		}
	}
		if(test!=0)
		{
		t=1;
		}
		if(test==0)
		t=2;
    }
return t;
}


/*=================================fonction rechercher stock=================================*/
void chercher_s(stock s)  
{
FILE* f; 
FILE* f1;
	char nom[30];
	int identifiant;
	char type[30];
	char quantite[30];
	int jour;
	char mois[30];
	char annee[30];
	int quantite_restante;

f=fopen("stock.txt","r");
f1=fopen("stockcher.txt","w");
 	while(fscanf(f,"%d %s %s %s %d %s %s %d\n",&identifiant,type,nom,quantite,&jour,mois,annee,&quantite_restante)!=EOF)
	{
		if (s.identifiant==identifiant)
		{
		fprintf(f1,"%d %s %s %s %d %s %s %d\n",identifiant,type,nom,quantite,jour,mois,annee,quantite_restante);
		}
	}
	fclose(f);
	fclose(f1);
}



/*=================================fonction afficher rechercher produit=================================*/
void afficher_s_chercher(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

	char nom[30];
	char type[30];
	int identifiant;
	char quantite[30];
	int jour;
	char mois[30];
	char annee[30];
	int quantite_restante;
	store=NULL;


FILE *f;
store = gtk_tree_view_get_model(liste);

if (store==NULL)
{


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",IDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",QUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("quantite restante",renderer,"text",QUANTITE_RESTANTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);
f=fopen("stockcher.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("stockcher.txt","a+");
		while(fscanf(f,"%d %s %s %s %d %s %s %d\n",&identifiant,type,nom,quantite,&jour,mois,annee,&quantite_restante)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter,IDENTIFIANT, identifiant,TYPE,type,NOM, nom,QUANTITE, quantite, JOUR, jour, MOIS, mois, ANNEE, annee, QUANTITE_RESTANTE, quantite_restante, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

}







































