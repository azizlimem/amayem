#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button_se_connecter_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_tech_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button_restau_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_stock_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_reclamation_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_etudiants_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button16_deconx_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button14_liste_users_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_stock_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_refresh_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_chercher_id_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajouter_s_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifier_s_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_alerte_stock_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_verifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajouter_produit_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_aj_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifier_produit_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_mod_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);



///////////////////////////////////////////////////////////////////////ahmed
void
on_button1_insc_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_auth_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_Retour_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1Capteur_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2Capteur_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_Type_modif_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button15_modifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_chercher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button17_verifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18_supprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_affListe_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_Histo_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_affdeff_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_Liste_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button19_retour_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_Histo_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button20_retour_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_captDeff_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_button23_actualiser_Liste_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22_actualiser_Histo_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_act_captdeff_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22_calcul_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2Capteur_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1Capteur_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);








///////////////////////////////////////////////////////////aziz

void
on_buttonadd_clicked                   (GtkWidget 	*objet,
                                        gpointer         user_data);

void
on_buttondisplay_clicked               (GtkWidget 	*objet,
                                        gpointer         user_data);

void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonreturn_clicked                (GtkWidget 	*objet,
                                        gpointer         user_data);

void
on_buttonsearch_clicked                (GtkWidget 	*objet,
                                        gpointer         user_data);




void
on_checkbutton_highc_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_lowc_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_update_clicked               (GtkWidget 	*objet,
                                        gpointer         user_data);


void
on_button_delete_clicked               (GtkWidget 	*objet,
                                        gpointer         user_data);

void
on_button_modify_clicked               (GtkWidget 	*objet,
                                        gpointer         user_data);

void
on_radiobuttonbig_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonsmall_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_buttonbestmenu_clicked              (GtkButton       *button,
                                        gpointer         user_data);
////////////////////////////////////////////////////////////////mariem

void
on_buttona_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonm_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaf_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttons_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonr_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffniveau_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttona1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuiv1_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonr1_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonsuiv2_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttons1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonm1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonaf2_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonrch1_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonsupp2_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton1_etud_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_etud_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_etud_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_etud_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton3_etud_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_etud_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview2_etud_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonrr2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrr3_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrr1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4qq_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonss1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
////////////////////////////////////////////////slah





void
on_radiobutton3_valide_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_heb_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nut_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_n_valide_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
void
on_button5_plus_reclamee_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button_add_reclam_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_reclam_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_reclam_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_reclam_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_recherche_reclam_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_reclam_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_reclam_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_retour_menu_reclam_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_recherche_id_reclam_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_reclam_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_retour_menu_reclam_clicked  (GtkButton       *objet_ghraphique,
                                        gpointer         user_data);

void
on_button_modifier_msg_reclam_clicked  (GtkButton       *button,
                                        gpointer         user_data);


void
on_button3_retour_menu_reclam_clicked  (GtkButton       *button,
                                        gpointer         user_data);


void
on_checkbutton1_reclam_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonretourmenu_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_retour_menu_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_retour_menu_reclam_clicked  (GtkButton       *button,
                                        gpointer         user_data);




void
on_button_quitter_stock_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_quitter_ahmed_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_quitter_aziz_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_quitter_etudiant_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);


