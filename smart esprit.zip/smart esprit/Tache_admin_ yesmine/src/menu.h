#include <gtk/gtk.h>
typedef struct{
	char id[20];
	char meal[20];
	char dessert[20];
	int day;
	int dechets;
	char type[20];
        char size[20] ;
        char cal[20];
}menu;

void add_menu(menu m,char *file);
void modify_menu(menu e,char *file);
void delete_menu(char id_menu[20],char *file);
void display_menu(char *file);
void search_menu(char id_menu[20],char *file);
void display_menu_ONtreeview(GtkWidget *list,char *file);
void meilleur_menu(  char *file);


