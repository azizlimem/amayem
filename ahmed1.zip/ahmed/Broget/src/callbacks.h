#include <gtk/gtk.h>


void
on_button1_insc_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_auth_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_Retour_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1Capteur_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2Capteur_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_Type_modif_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button15_modifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_chercher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button17_verifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18_supprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_affListe_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_Histo_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_affdeff_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_Liste_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button19_retour_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_Histo_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button20_retour_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_captDeff_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_Quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_actualiser_Liste_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22_actualiser_Histo_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_act_captdeff_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22_calcul_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2Capteur_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1Capteur_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
